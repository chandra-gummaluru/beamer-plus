/**
 * Beamer+ guided tour.
 *
 * Usage:
 *   import { startTour } from './app/tour.js';
 *   startTour();
 */

const PAD = 8;    // padding added around the spotlight rect
const GAP = 14;   // gap between spotlight edge and popover

/* ── Tour steps ─────────────────────────────────────────────── */
const STEPS = [
    {
        sel:   null,
        place: 'center',
        title: 'Welcome to Beamer+',
        body:  'Beamer+ is an interactive presentation tool that turns a PDF slide deck into a live lecture: draw on your slides, and drop in videos, 3D models, live polls and interactive widgets.',
    },
    {
        sel:   '#top-right-controls',
        place: 'auto',
        title: 'Your Session',
        body:  'Edit the presentation, and close the session when you are done (it asks whether to save first). A new session starts by opening a presentation: a plain PDF, or a saved Beamer+ ZIP with its widgets and annotations, from a folder on this computer or dropped on the window.',
    },
    {
        sel:   '#slide-navigator',
        place: 'right',
        title: 'Slide Navigator',
        body:  'Thumbnail strip of all your slides. Click any thumbnail to jump directly to it. In edit mode you can drag thumbnails to reorder slides.',
    },
    {
        sel:   '#annotation-slide-actions',
        place: 'left',
        title: 'Add or Duplicate Slides',
        body:  'At the bottom of the toolbar, after Split View: the first button adds a page after the current one; the second duplicates the current slide (its widgets, media and ink included) so you can build a variation without touching the original.',
    },
    {
        sel:   '#nav-drawer-hinge',
        place: 'right',
        title: 'Hide the Navigator',
        body:  'Click this hinge to slide the navigator away and give the slide more room. Click it again to bring the navigator back.',
    },
    {
        sel:   '#split-toggle',
        place: 'left',
        title: 'Split View',
        body:  'Split the stage into two independent panes. Show your notes on one side while the audience slide stays in place on the other, or jump ahead while the current slide stays visible.',
    },
    {
        sel:   '#floating-annotation-toolbar',
        place: 'left',
        title: 'Annotation Tools',
        body:  'Draw on slides in real time. Choose from the hand pointer, spotlight, pen, or eraser. Undo, redo, or clear all at any time.',
    },
    {
        sel:   '#spotlight-btn',
        place: 'left',
        title: 'Spotlight',
        body:  'Dims everything except a movable circle so your audience focuses exactly where you want. Drag the spotlight around the slide to move it.',
    },
    {
        sel:   '#magnify-btn',
        place: 'left',
        title: 'Magnifier',
        body:  'A round lens that follows the pointer and enlarges whatever is under it, including ink, video and widgets. Scroll while it is active to zoom between 1.5× and 5×. Try it on the fine print on the ink slide.',
    },
    {
        sel:   '#text-btn',
        place: 'left',
        title: 'Text Boxes with LaTeX',
        body:  'Click anywhere on a slide to type a note. Wrap math in $…$ and it is typeset as LaTeX, right on the slide.',
    },
    {
        sel:   '#session-edit-btn',
        place: 'auto',
        title: 'Edit Mode',
        body:  'Edit presentation lets you add videos, audio, 3D models, and interactive widgets to any slide from the toolbar along the top. The panel on the right shows the slide and everything on it; click anything to open its settings there. Drag and resize overlays freely.',
    },
    {
        sel:   '#record-btn',
        place: 'left',
        title: 'Record the Lecture',
        body:  'Record this tab as a video: slides, ink, widgets, your microphone and the tab\'s sound. Takes are saved every second, so a reload or crash loses nothing, and they are offered when you Save.',
    },
    {
        sel:   '#mute-btn',
        place: 'left',
        title: 'Hide the Slide',
        body:  'Blank the stage for a moment (or press .), handy for a question or a pause. You can keep moving through slides while it is hidden.',
    },
    {
        sel:   '#session-close-btn',
        place: 'auto',
        title: 'Save and Close',
        body:  'When you are done, Close session asks whether to save first: pick the folder and file name, and what to save: the deck (it reopens where you left off), the notes PDF (annotations, widgets, media and poll results drawn in) and any recordings.',
    },
    {
        sel:   null,
        place: 'center',
        title: 'Now Explore the Demo',
        body:  'Press → to step through the demo deck. Every slide is live: uncover a proof step by step, play a video that grows to fill the slide, rotate a 3D heart, drag a slider on a 3D surface, flip switches on an SR latch, run Python, and answer a live poll from your phone.',
    },
];

/* ── State ──────────────────────────────────────────────────── */
let _step  = 0;
let _nodes = null; // { backdrop, spotlight, popover, title, body, count, prev, next }
let _keyFn = null;

/* ── Public API ─────────────────────────────────────────────── */
export async function startTour(loadDemo) {
    if (_nodes) return; // already active
    if (loadDemo) await loadDemo();
    _step = 0;
    _mount();
    _goto(0);
}

function endTour() {
    if (!_nodes) return;
    document.removeEventListener('keydown', _keyFn, { capture: true });
    _nodes.backdrop.remove();
    _nodes.spotlight.remove();
    _nodes.popover.remove();
    _nodes = null;
    _keyFn = null;
}

/* ── DOM construction ───────────────────────────────────────── */
function _mount() {
    // Backdrop — blocks all pointer events on the page during the tour
    const backdrop = _el('div', 'tour-backdrop');

    // Spotlight — uses box-shadow to dim everything outside the target rect
    const spotlight = _el('div', 'tour-spotlight');

    // Popover card
    const popover = _el('div', 'tour-popover');
    popover.innerHTML = `
        <div class="tour-pop-header">
            <span class="tour-count"></span>
            <button class="link tour-skip-btn" aria-label="Skip Tour">Skip</button>
        </div>
        <h3 class="tour-title"></h3>
        <p  class="tour-body"></p>
        <div class="tour-nav-row">
            <button class="btn btn--sm tour-back-btn">Back</button>
            <button class="btn btn--sm btn--primary tour-next-btn">Next</button>
        </div>
    `;

    document.body.append(backdrop, spotlight, popover);

    const prev = popover.querySelector('.tour-back-btn');
    const next = popover.querySelector('.tour-next-btn');
    const skip = popover.querySelector('.tour-skip-btn');

    skip.addEventListener('click', endTour);
    prev.addEventListener('click', () => _goto(_step - 1));
    next.addEventListener('click', () => {
        if (_step >= STEPS.length - 1) endTour();
        else _goto(_step + 1);
    });

    _keyFn = (e) => {
        if (e.key === 'ArrowRight' || e.key === 'Enter') {
            e.stopPropagation();
            if (_step >= STEPS.length - 1) endTour();
            else _goto(_step + 1);
        } else if (e.key === 'ArrowLeft') {
            e.stopPropagation();
            _goto(_step - 1);
        } else if (e.key === 'Escape') {
            e.stopPropagation();
            endTour();
        }
    };
    document.addEventListener('keydown', _keyFn, { capture: true });

    _nodes = {
        backdrop, spotlight, popover,
        title:  popover.querySelector('.tour-title'),
        body:   popover.querySelector('.tour-body'),
        count:  popover.querySelector('.tour-count'),
        prev, next,
    };
}

/* ── Step navigation ────────────────────────────────────────── */
function _goto(i) {
    _step = Math.max(0, Math.min(STEPS.length - 1, i));
    const step = STEPS[_step];
    const n    = _nodes;
    const last = _step === STEPS.length - 1;

    // Update text content
    n.count.textContent = `${_step + 1} of ${STEPS.length}`;
    n.title.textContent = step.title;
    n.body.textContent  = step.body;
    n.prev.style.visibility = _step === 0 ? 'hidden' : '';
    n.next.textContent = last ? 'Finish' : 'Next';

    // Resolve target element
    let target = step.sel ? document.querySelector(step.sel) : null;
    // A control this layout hides (e.g. the drawer hinge on a narrow screen)
    // has no box to spotlight — explain it centred instead.
    if (target && !target.getClientRects().length) target = null;

    if (!target || step.place === 'center') {
        // Welcome / no-target: full-screen dim, centered popover
        n.backdrop.style.background = 'var(--scrim)';
        n.spotlight.style.opacity   = '0';
        n.popover.dataset.placement = 'center';
        _centerPopover();
    } else {
        n.backdrop.style.background = 'transparent';
        n.spotlight.style.opacity   = '1';
        const r = target.getBoundingClientRect();
        _positionSpotlight(r);
        // Defer popover positioning one frame so the browser has the latest layout
        requestAnimationFrame(() => _positionPopover(r, step.place));
    }
}

/* ── Spotlight positioning ──────────────────────────────────── */
function _positionSpotlight(r) {
    const s = _nodes.spotlight.style;
    s.left   = `${r.left   - PAD}px`;
    s.top    = `${r.top    - PAD}px`;
    s.width  = `${r.width  + PAD * 2}px`;
    s.height = `${r.height + PAD * 2}px`;
}

/* ── Popover positioning ────────────────────────────────────── */
function _positionPopover(r, placement) {
    const pop = _nodes.popover;
    const pw  = pop.offsetWidth  || 300;
    const ph  = pop.offsetHeight || 200;
    const vw  = window.innerWidth;
    const vh  = window.innerHeight;
    const m   = 10; // min margin from viewport edge

    // Pick best side when 'auto'
    let side = placement;
    if (side === 'auto') {
        const space = {
            right:  vw - r.right,
            left:   r.left,
            bottom: vh - r.bottom,
            top:    r.top,
        };
        side = Object.entries(space).reduce((a, b) => a[1] > b[1] ? a : b)[0];
    }

    let left, top;
    switch (side) {
        case 'right':
            left = r.right + GAP;
            top  = _clamp(r.top + r.height / 2 - ph / 2, m, vh - ph - m);
            break;
        case 'left':
            left = r.left - pw - GAP;
            top  = _clamp(r.top + r.height / 2 - ph / 2, m, vh - ph - m);
            break;
        case 'top':
            left = _clamp(r.left + r.width / 2 - pw / 2, m, vw - pw - m);
            top  = r.top - ph - GAP;
            break;
        default: // bottom
            left = _clamp(r.left + r.width / 2 - pw / 2, m, vw - pw - m);
            top  = r.bottom + GAP;
    }

    pop.dataset.placement = side;
    pop.style.left = `${left}px`;
    pop.style.top  = `${top}px`;
}

function _centerPopover() {
    const pop = _nodes.popover;
    requestAnimationFrame(() => {
        const pw = pop.offsetWidth  || 300;
        const ph = pop.offsetHeight || 200;
        pop.style.left = `${(window.innerWidth  - pw) / 2}px`;
        pop.style.top  = `${(window.innerHeight - ph) / 2}px`;
    });
}

/* ── Helpers ────────────────────────────────────────────────── */
function _clamp(v, lo, hi) { return Math.max(lo, Math.min(hi, v)); }
function _el(tag, id) {
    const e = document.createElement(tag);
    e.id = id;
    return e;
}
