// Widget settings form — the controls for a widget's own declared fields,
// built from its `widget-schema` block (see editor/widget-schema.js).
//
// Two hosts: the widget's settings sheet, opened from its pencil while
// presenting (widget-settings-dialog.js, variant 'sheet'), and the editor
// panel, which only shows Text size (widget-panel.js, variant 'panel'). A
// choice of two or three short options is drawn as a segmented control and
// Text size as a row of growing A's.
//
// Beyond the basic field types, a schema can opt into richer editing with
// hints that the in-widget settings kit simply ignores — so the kit keeps
// working unchanged on the same schema:
//
//   section: "Answers"        Starts a group. Fields without one join the
//                             group above them. Groups whose fields are all
//                             hidden (showIf) hide too.
//   mono: true                Monospace textarea, for code.
//   editor: "list"            On a textarea-lines field: one input per line,
//                             with add / remove, Enter for a new row, and
//                             multi-line paste split into rows.
//     correct: { key, base }  …plus a "correct answer" toggle on each row,
//                             written as a (base-indexed) position to `key`.
//                             That field is then edited here, not on its own.
//     itemPlaceholder: "…"    Placeholder for each row ("Option 1", …).
//   blanks: { pattern, insert }
//                             On a textarea: a template editor that
//                             highlights every match of `pattern`, counts
//                             them, and has a button that turns the
//                             selection into `insert`.
//
// Every control sits inside the form's root and reports changes as bubbling
// `input` events, so whoever hosts the form applies them with one listener.
import { ctx, WIDGET_RESERVED } from './context.js';
import { saveWidgetAsset } from './widget-settings.js';
import { titleCase } from './title-case.js';
import { sessionUrl } from '../app/session.js';

/**
 * @param {{label?:string, fields:object[]}} schema
 * @param {object} item            the widget's config item (read for initial values)
 * @param {'panel'|'sheet'} variant  panel: everything under one General
 *                                  group; sheet: the widget's own settings,
 *                                  in its schema sections
 * @returns {{ node: HTMLElement, apply(item): void, syncVisibility(): void, focusFirst(): void }}
 */
export function buildWidgetForm(schema, item, variant = 'panel') {
    const root = document.createElement('div');
    root.className = `wf wf--${variant}`;

    // Fields another control edits on their behalf (a list's correct answer).
    const claimed = new Set();
    for (const f of schema.fields) {
        if (isListField(f) && f.correct?.key) claimed.add(f.correct.key);
    }

    const rows = [];
    const groups = [];
    let group = null;
    // In the panel, everything sits under "General"; the panel puts its
    // Layout section after it.
    let common = null;
    for (const field of schema.fields) {
        if (claimed.has(field.key)) continue;
        if (variant === 'panel') {
            if (!common) {
                common = makeGroup('General');
                groups.push(common);
                root.insertBefore(common.node, root.firstChild);
            }
            const row = buildFieldRow(field, item, variant);
            row.field = field;
            row.group = common;
            rows.push(row);
            common.body.appendChild(row.node);
            continue;
        }
        if (!group || (field.section && field.section !== group.title)) {
            group = makeGroup(field.section || '');
            groups.push(group);
            root.appendChild(group.node);
        }
        const row = buildFieldRow(field, item, variant);
        row.field = field;
        row.group = group;
        if (row.wide) group.node.classList.add('is-wide');
        rows.push(row);
        group.body.appendChild(row.node);
    }

    function values() {
        const out = {};
        for (const r of rows) {
            const res = r.read();
            out[r.key] = res.remove ? r.field.default : res.value;
        }
        return out;
    }

    // A field may declare `showIf: { otherKey: value | [values] }` — it only
    // applies while another field holds one of those values (an answer list
    // means nothing to an open-ended poll). Hidden rather than removed, so its
    // value is kept and switching back restores what the presenter typed.
    function syncVisibility() {
        const vals = values();
        for (const r of rows) r.node.hidden = !fieldVisible(r.field, vals);
        for (const g of groups) {
            g.node.hidden = !rows.some(r => r.group === g && !r.node.hidden);
        }
    }

    // Write every field back onto the item. A cleared field is deleted rather
    // than stored empty, so the widget falls back to its own default exactly
    // as it would through its in-widget panel.
    function apply(target) {
        for (const r of rows) {
            if (WIDGET_RESERVED.has(r.key)) continue;   // a widget can't move itself
            const res = r.read();
            if (res.remove) delete target[r.key]; else target[r.key] = res.value;
            for (const [k, extra] of Object.entries(res.extra || {})) {
                if (WIDGET_RESERVED.has(k)) continue;
                if (extra.remove) delete target[k]; else target[k] = extra.value;
            }
        }
    }

    function focusFirst() {
        rows.find(r => !r.node.hidden)?.node.querySelector('input, textarea, select')?.focus();
    }

    syncVisibility();
    return { node: root, apply, syncVisibility, focusFirst, commonNode: common?.node || null };
}

/* ─── groups ─────────────────────────────────────────────────────────── */

function makeGroup(title) {
    const node = document.createElement('div');
    node.className = 'wf-group';
    if (title) {
        const h = document.createElement('div');
        h.className = 'wf-group-title';
        h.textContent = titleCase(title);
        node.appendChild(h);
    }
    const body = document.createElement('div');
    body.className = 'wf-group-body';
    node.appendChild(body);
    return { title, node, body };
}

function fieldVisible(field, values) {
    const cond = field?.showIf;
    if (!cond || typeof cond !== 'object') return true;
    return Object.keys(cond).every(k => {
        const want = Array.isArray(cond[k]) ? cond[k] : [cond[k]];
        return want.some(w => String(w) === String(values[k]));
    });
}

/* ─── rows ───────────────────────────────────────────────────────────── */

// What a control should show: what the presenter set, else the schema's default.
function fieldValue(item, field) {
    const v = item[field.key];
    return v !== undefined ? v : field.default;
}

function fieldLabel(field) {
    const lab = document.createElement('div');
    lab.className = 'editor-prop-label';
    lab.textContent = titleCase(field.label || field.key);
    // A schema field's `note` is no longer shown: the editor keeps labels
    // to the label alone, without grey asides.
    return lab;
}

const INLINE_TYPES = new Set(['select', 'ai-model', 'number', 'number-nullable']);

const isListField     = (f) => f?.type === 'textarea-lines' && f.editor === 'list';
const isTemplateField = (f) => f?.type === 'textarea' && f.blanks && typeof f.blanks === 'object';

// One control per declared field. Mirrors the widget settings kit's field
// types and read() semantics — notably that clearing a field drops the key
// so the widget's own default applies again — so a widget behaves the same
// whichever surface configured it.
function buildFieldRow(field, item, variant) {
    if (field.type === 'colour-counts') return buildColourCountsRow(field, item);
    if (field.type === 'select-list')   return buildSelectListRow(field, item);
    if (isListField(field))     return buildListRow(field, item);
    if (isTemplateField(field)) return buildTemplateRow(field, item, variant);

    const eff = fieldValue(item, field);
    const row = document.createElement('div');
    row.className = 'editor-prop-row';
    let input, wide = false, skipInline = false;

    if (field.type === 'checkbox') {
        // An on/off setting is the same switch row as the slide's own
        // "Hide in presentation": label on the left, switch on the right.
        const lab = document.createElement('label');
        lab.className = 'editor-prop-checkbox-row';
        const text = document.createElement('span');
        text.textContent = titleCase(field.label || field.key);
        input = document.createElement('input');
        input.type = 'checkbox';
        input.className = 'editor-switch';
        input.setAttribute('role', 'switch');
        input.checked = eff === true;
        lab.appendChild(text);
        lab.appendChild(input);
        row.appendChild(lab);

    } else if (field.type === 'select') {
        row.appendChild(fieldLabel(field));
        input = document.createElement('select');
        input.className = 'field';
        for (const o of field.options || []) {
            const isObj = o && typeof o === 'object';
            const value = isObj ? o.v : o;
            const label = isObj ? (o.l !== undefined ? o.l : o.v) : o;
            const opt = document.createElement('option');
            opt.value = value;
            opt.textContent = titleCase(String(label));
            // A short line under the option in the dropdown's menu (dropdown.js).
            if (isObj && o.d) opt.dataset.desc = o.d;
            // Compared as strings: a deck may hold 1.4 where the schema
            // declares "1.4", and a strict compare would lose the selection.
            if (String(eff) === String(value)) opt.selected = true;
            input.appendChild(opt);
        }
        // A saved value that isn't one of the options (an older deck's 1.8 on
        // a list that now steps 1.7, 2): pick the nearest number rather than
        // silently showing the first option.
        const matched = (field.options || []).some(o => String(o && typeof o === 'object' ? o.v : o) === String(eff));
        if (!matched) {
            const n = parseFloat(eff);
            if (!isNaN(n)) {
                let best = -1, bestD = Infinity;
                Array.from(input.options).forEach((o, i) => {
                    const d = Math.abs(parseFloat(o.value) - n);
                    if (d < bestD) { bestD = d; best = i; }
                });
                if (best >= 0) input.selectedIndex = best;
            }
        }
        row.appendChild(input);
        // A choice of two or three is a row of buttons you can see all of at
        // once, and Text size is a row of A's growing in size. The select
        // stays (hidden) as the value everything else reads.
        {
            const seg = field.key === 'scale' ? buildSizePicker(input)
                      : input.options.length >= 2 && input.options.length <= 3
                        && Array.from(input.options).every(o => o.textContent.length <= 14) ? buildSegmented(input)
                      : null;
            if (seg) {
                input.hidden = true;
                row.appendChild(seg);
                row.classList.add('editor-prop-row--seg');
                skipInline = true;
            }
        }

    } else if (field.type === 'ai-model') {
        row.appendChild(fieldLabel(field));
        input = document.createElement('select');
        input.className = 'field';
        fillModelOptions(input, eff);
        row.appendChild(input);

    } else if (field.type === 'textarea' || field.type === 'textarea-lines') {
        const lab = fieldLabel(field);
        row.appendChild(lab);
        input = document.createElement('textarea');
        input.className = 'field editor-prop-area' + (field.mono ? ' wf-mono' : '');
        input.rows = field.rows || (field.type === 'textarea-lines' ? 4 : 3);
        input.spellcheck = false;
        if (field.placeholder) input.placeholder = field.placeholder;
        input.value = Array.isArray(eff) ? eff.join('\n') : (eff == null ? '' : String(eff));
        row.appendChild(input);
        autoGrow(input);
        wide = true;

    } else if (field.type === 'file') {
        row.appendChild(fieldLabel(field));
        const fileRow = document.createElement('div');
        fileRow.className = 'editor-prop-file';
        input = document.createElement('input');
        input.className = 'field';
        input.type = 'text';
        input.readOnly = true;
        input.placeholder = 'No file selected';
        input.value = eff == null ? '' : String(eff);
        input.title = input.value;
        const btn = document.createElement('button');
        btn.type = 'button';
        btn.className = 'btn btn--sm editor-prop-file-btn';
        btn.textContent = 'Upload';
        btn.addEventListener('click', () => pickWidgetAsset(field, item, input, btn));
        fileRow.appendChild(input);
        fileRow.appendChild(btn);
        row.appendChild(fileRow);

    } else if (field.type === 'duration') {
        // A length of time, stored as whole seconds but typed as minutes and
        // seconds — nobody wants to work out that 7½ minutes is 450.
        row.appendChild(fieldLabel(field));
        const wrap = document.createElement('div');
        wrap.className = 'wf-duration';
        const part = (unit, aria) => {
            const lab = document.createElement('label');
            lab.className = 'wf-duration-part';
            const i = document.createElement('input');
            i.className = 'field';
            i.type = 'number';
            i.min = '0';
            i.step = '1';
            i.inputMode = 'numeric';
            i.setAttribute('aria-label', aria);
            const u = document.createElement('span');
            u.className = 'wf-duration-unit';
            u.textContent = unit;
            lab.append(i, u);
            wrap.appendChild(lab);
            return i;
        };
        const mins = part('min', `${field.label || field.key} — minutes`);
        const secs = part('sec', `${field.label || field.key} — seconds`);
        const show = (total, into) => {
            const t = Math.max(0, Math.round(Number(total)));
            into[0].value = String(Math.floor(t / 60));
            into[1].value = String(t % 60);
        };
        if (eff != null && eff !== '' && isFinite(Number(eff))) show(eff, [mins, secs]);
        else if (field.default != null && isFinite(Number(field.default))) {
            const t = Math.round(Number(field.default));
            mins.placeholder = String(Math.floor(t / 60));
            secs.placeholder = String(t % 60);
        }
        // 90 seconds typed into the seconds box reads back as 1 min 30 sec.
        wrap.addEventListener('change', () => {
            const total = durationTotal(mins, secs);
            if (total != null) show(total, [mins, secs]);
        });
        row.appendChild(wrap);
        input = { mins, secs };

    } else {
        row.appendChild(fieldLabel(field));
        input = document.createElement('input');
        input.className = 'field';
        input.type = field.type === 'password' ? 'password'
                   : (field.type === 'number' || field.type === 'number-nullable') ? 'number'
                   : 'text';
        if (field.min  !== undefined) input.min  = field.min;
        if (field.max  !== undefined) input.max  = field.max;
        if (field.step !== undefined) input.step = field.step;
        if (field.placeholder) input.placeholder = field.placeholder;
        input.value = eff == null ? '' : String(eff);
        row.appendChild(input);
    }

    // Short controls sit on the label's line, at the width their values
    // need, instead of stretching under it across the whole card.
    if (INLINE_TYPES.has(field.type) && !skipInline) row.classList.add('editor-prop-row--inline');

    return {
        key: field.key,
        node: row,
        wide,
        read() {
            if (field.type === 'checkbox') return { value: input.checked };
            if (field.type === 'duration') {
                const total = durationTotal(input.mins, input.secs);
                if (total == null) return { remove: true };
                const min = field.min !== undefined ? Number(field.min) : 1;
                return { value: Math.max(min, total) };
            }
            if (field.type === 'number' || field.type === 'number-nullable') {
                const raw = input.value.trim();
                if (raw === '') return { remove: true };
                const n = parseFloat(raw);
                return isNaN(n) ? { remove: true } : { value: n };
            }
            if (field.type === 'textarea-lines') {
                const lines = input.value.split('\n').map(s => s.trim()).filter(Boolean);
                return lines.length ? { value: lines } : { remove: true };
            }
            return input.value === '' ? { remove: true } : { value: input.value };
        },
    };
}

/* ─── visual pickers over a <select> ─────────────────────────────────── */
// Each button sets the hidden select and fires the change the dialog
// listens for, so reading, showIf and saving work exactly as for a select.

function pickerButton(select, opt, inner, cls) {
    const b = document.createElement('button');
    b.type = 'button';
    b.className = cls;
    b.dataset.v = opt.value;
    b.title = opt.textContent;
    b.setAttribute('aria-label', opt.textContent);
    b.innerHTML = inner;
    b.addEventListener('click', () => {
        if (select.value === opt.value) return;
        select.value = opt.value;
        select.dispatchEvent(new Event('change', { bubbles: true }));
    });
    return b;
}

function syncPicker(wrap, select) {
    const mark = () => wrap.querySelectorAll('button').forEach(b => {
        const on = b.dataset.v === select.value;
        b.classList.toggle('is-active', on);
        b.setAttribute('aria-pressed', on ? 'true' : 'false');
    });
    select.addEventListener('change', mark);
    mark();
}

function buildSegmented(select) {
    const wrap = document.createElement('div');
    wrap.className = 'wf-seg';
    wrap.setAttribute('role', 'group');
    for (const opt of select.options) {
        const b = pickerButton(select, opt, '', 'wf-seg-btn');
        b.textContent = opt.textContent;
        b.removeAttribute('aria-label');
        wrap.appendChild(b);
    }
    syncPicker(wrap, select);
    return wrap;
}

function buildSizePicker(select) {
    const wrap = document.createElement('div');
    wrap.className = 'wf-sizes';
    wrap.setAttribute('role', 'group');
    const opts = Array.from(select.options);
    opts.forEach((opt, i) => {
        // 11px → 21px across the steps: the size you pick, drawn.
        const px = Math.round(11 + (10 * i) / Math.max(1, opts.length - 1));
        wrap.appendChild(pickerButton(select, opt, `<span style="font-size:${px}px">A</span>`, 'wf-size-btn'));
    });
    syncPicker(wrap, select);
    return wrap;
}

// Minutes + seconds boxes → whole seconds, or null when both are empty.
function durationTotal(mins, secs) {
    const m = mins.value.trim(), s = secs.value.trim();
    if (m === '' && s === '') return null;
    const total = (parseFloat(m) || 0) * 60 + (parseFloat(s) || 0);
    return Math.max(0, Math.round(total));
}

// Grow a textarea with its content (between its `rows` and a cap), so a long
// question never hides behind a scrollbar in a box three lines tall.
function autoGrow(ta) {
    const cap = 320;
    const fit = () => {
        if (!ta.isConnected) return;
        ta.style.height = 'auto';
        ta.style.height = `${Math.min(cap, ta.scrollHeight + 2)}px`;
    };
    ta.addEventListener('input', fit);
    // Not measurable until it's in the document and visible — a field hidden
    // by showIf has no width — so refit whenever the width changes (which is
    // also when the wrapping, and so the height it needs, changes).
    requestAnimationFrame(fit);
    let lastW = 0;
    new ResizeObserver((entries) => {
        const w = entries[0]?.contentRect.width || 0;
        if (w && w !== lastW) { lastW = w; requestAnimationFrame(fit); }
    }).observe(ta);
    return fit;
}

/* ─── list editor ────────────────────────────────────────────────────── */

// An array of short strings, one input each. Stored exactly as the plain
// textarea-lines field would store it (blank rows dropped), so the widget
// reads it unchanged.
function buildListRow(field, item) {
    const row = document.createElement('div');
    row.className = 'editor-prop-row wf-list-row';
    row.appendChild(fieldLabel(field));

    const correct = field.correct?.key ? { key: field.correct.key, base: field.correct.base ?? 1 } : null;
    const list = document.createElement('div');
    list.className = 'wf-list' + (correct ? ' has-correct' : '');
    list.setAttribute('role', 'list');
    row.appendChild(list);

    const add = document.createElement('button');
    add.type = 'button';
    add.className = 'wf-list-add';
    add.innerHTML = '<span aria-hidden="true">+</span> Add';
    add.setAttribute('aria-label', 'Add ' + (field.itemLabel || 'option').toLowerCase());
    row.appendChild(add);

    const initial = fieldValue(item, field);
    const values = Array.isArray(initial) ? initial.map(String)
                 : typeof initial === 'string' ? initial.split('\n') : [];
    // The stored correct answer points into the stored list, which never
    // holds blank rows — so it maps straight onto the rows built here.
    let correctRow = null;
    if (correct) {
        const n = parseInt(item[correct.key], 10);
        if (!isNaN(n) && n - correct.base >= 0 && n - correct.base < values.length) correctRow = n - correct.base;
    }

    const changed = () => list.dispatchEvent(new Event('input', { bubbles: true }));
    const inputs = () => Array.from(list.querySelectorAll('.wf-list-input'));

    function renumber() {
        inputs().forEach((inp, i) => {
            const r = inp.closest('.wf-list-item');
            r.querySelector('.wf-list-num').textContent = String(i + 1);
            inp.placeholder = field.itemPlaceholder ? `${field.itemPlaceholder} ${i + 1}` : '';
            const mark = r.querySelector('.wf-list-correct');
            if (mark) {
                const on = i === correctRow;
                mark.setAttribute('aria-pressed', on ? 'true' : 'false');
                mark.title = on ? 'Correct answer — click to unmark' : 'Mark as the correct answer';
                r.classList.toggle('is-correct', on);
            }
        });
        list.querySelectorAll('.wf-list-remove').forEach(b => { b.disabled = inputs().length <= 1; });
    }

    function makeItem(value) {
        const r = document.createElement('div');
        r.className = 'wf-list-item';
        r.setAttribute('role', 'listitem');
        const num = document.createElement('span');
        num.className = 'wf-list-num';
        const inp = document.createElement('input');
        inp.type = 'text';
        inp.className = 'field wf-list-input';
        inp.value = value;
        inp.spellcheck = false;
        r.appendChild(num);
        r.appendChild(inp);
        if (correct) {
            const mark = document.createElement('button');
            mark.type = 'button';
            mark.className = 'wf-list-correct';
            mark.innerHTML = '<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polyline points="20 6 9 17 4 12"/></svg>';
            mark.addEventListener('click', () => {
                const i = inputs().indexOf(inp);
                correctRow = correctRow === i ? null : i;
                renumber(); changed();
            });
            r.appendChild(mark);
        }
        const rm = document.createElement('button');
        rm.type = 'button';
        rm.className = 'wf-list-remove';
        rm.title = 'Remove';
        rm.setAttribute('aria-label', 'Remove');
        rm.innerHTML = '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" aria-hidden="true"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>';
        rm.addEventListener('click', () => removeItem(inp, false));
        r.appendChild(rm);

        inp.addEventListener('keydown', (e) => {
            const all = inputs(), i = all.indexOf(inp);
            if (e.key === 'Enter') {
                e.preventDefault();
                const next = insertItemAfter(r, '');
                next.focus();
                changed();
            } else if (e.key === 'Backspace' && inp.value === '' && all.length > 1) {
                e.preventDefault();
                removeItem(inp, true);
            } else if (e.key === 'ArrowUp' && i > 0) {
                e.preventDefault(); all[i - 1].focus();
            } else if (e.key === 'ArrowDown' && i < all.length - 1) {
                e.preventDefault(); all[i + 1].focus();
            }
        });
        // Pasting several lines (answers copied from a document) fills
        // several rows rather than cramming them into one.
        inp.addEventListener('paste', (e) => {
            const text = e.clipboardData?.getData('text/plain') || '';
            if (!/\r?\n/.test(text)) return;
            e.preventDefault();
            const lines = text.split(/\r?\n/).map(s => s.trim()).filter(Boolean);
            if (!lines.length) return;
            const { selectionStart: s = inp.value.length, selectionEnd: t = inp.value.length } = inp;
            inp.value = inp.value.slice(0, s) + lines[0] + inp.value.slice(t);
            let after = r;
            for (const line of lines.slice(1)) after = insertItemAfter(after, line).closest('.wf-list-item');
            after.querySelector('.wf-list-input').focus();
            changed();
        });
        return r;
    }

    function insertItemAfter(refRow, value) {
        const before = inputs().indexOf(refRow.querySelector('.wf-list-input'));
        const r = makeItem(value);
        refRow.after(r);
        // Rows after the insertion shift down one; keep the correct mark on
        // the same answer.
        if (correctRow != null && correctRow > before) correctRow++;
        renumber();
        return r.querySelector('.wf-list-input');
    }

    function removeItem(inp, focusPrev) {
        const all = inputs();
        if (all.length <= 1) { inp.value = ''; changed(); return; }
        const i = all.indexOf(inp);
        if (correctRow === i) correctRow = null;
        else if (correctRow != null && correctRow > i) correctRow--;
        inp.closest('.wf-list-item').remove();
        renumber();
        const rest = inputs();
        if (focusPrev) {
            const t = rest[Math.max(0, i - 1)];
            t.focus(); t.setSelectionRange(t.value.length, t.value.length);
        }
        changed();
    }

    // Start with room to type: at least two rows for a fresh widget.
    const start = values.length ? values : ['', ''];
    for (const v of start) list.appendChild(makeItem(v));
    renumber();

    add.addEventListener('click', () => {
        const all = inputs();
        const last = all[all.length - 1];
        // Reuse a trailing empty row instead of stacking blanks.
        const target = last && last.value === '' ? last : insertItemAfter(last.closest('.wf-list-item'), '');
        target.focus();
        changed();
    });

    return {
        key: field.key,
        node: row,
        wide: true,
        read() {
            const raw = inputs().map(i => i.value.trim());
            const kept = raw.filter(Boolean);
            const res = kept.length ? { value: kept } : { remove: true };
            if (correct) {
                // Position among the non-blank answers — that is the list the
                // widget actually receives.
                const ok = correctRow != null && raw[correctRow];
                const pos = ok ? raw.slice(0, correctRow).filter(Boolean).length : null;
                res.extra = { [correct.key]: pos == null ? { remove: true } : { value: pos + correct.base } };
            }
            return res;
        },
    };
}

/* ─── template editor ────────────────────────────────────────────────── */

// A code template with gaps. The textarea is transparent over a mirror that
// paints the same text, so every gap can be highlighted in place while the
// textarea still does all the actual editing (caret, selection, undo).
function buildTemplateRow(field, item, variant) {
    const eff = fieldValue(item, field);
    let pattern;
    try { pattern = new RegExp(field.blanks.pattern || '\\bBLANK\\b', 'g'); }
    catch (_) { pattern = /\bBLANK\b/g; }
    const token = field.blanks.insert || 'BLANK';

    const row = document.createElement('div');
    row.className = 'editor-prop-row wf-template';
    row.appendChild(fieldLabel(field));

    const bar = document.createElement('div');
    bar.className = 'wf-template-bar';
    const insert = document.createElement('button');
    insert.type = 'button';
    insert.className = 'wf-chip-btn';
    insert.title = `Insert ${token} at the cursor, or turn the selected text into one`;
    insert.innerHTML = `<span class="wf-blank-chip">${escText(token)}</span> Insert Blank`;
    const count = document.createElement('span');
    count.className = 'wf-blank-count';
    bar.appendChild(insert);
    bar.appendChild(count);
    row.appendChild(bar);

    const box = document.createElement('div');
    box.className = 'wf-code';
    const mirror = document.createElement('div');
    mirror.className = 'wf-code-mirror';
    mirror.setAttribute('aria-hidden', 'true');
    const ta = document.createElement('textarea');
    ta.className = 'wf-code-input';
    ta.rows = field.rows || 6;
    ta.spellcheck = false;
    ta.wrap = 'soft';
    if (field.placeholder) ta.placeholder = field.placeholder;
    ta.value = eff == null ? '' : String(eff);
    box.appendChild(mirror);
    box.appendChild(ta);
    row.appendChild(box);

    function paint() {
        const text = ta.value;
        let html = '', last = 0, n = 0;
        pattern.lastIndex = 0;
        for (let m; (m = pattern.exec(text)); ) {
            if (!m[0]) { pattern.lastIndex++; continue; }
            html += escText(text.slice(last, m.index)) + `<mark>${escText(m[0])}</mark>`;
            last = m.index + m[0].length;
            n++;
        }
        // A trailing newline needs something after it, or the mirror's last
        // line collapses and the highlights drift a line off.
        mirror.innerHTML = html + escText(text.slice(last)) + '​';
        count.textContent = n === 0 ? 'No blanks yet' : n === 1 ? '1 blank' : `${n} blanks`;
        count.classList.toggle('is-empty', n === 0);
        mirror.scrollTop = ta.scrollTop;
    }
    const grow = autoGrow(ta);
    ta.addEventListener('input', paint);
    ta.addEventListener('scroll', () => { mirror.scrollTop = ta.scrollTop; });
    // Tab indents (it's code); Shift+Tab / Esc still leave the field.
    ta.addEventListener('keydown', (e) => {
        if (e.key !== 'Tab' || e.shiftKey || e.altKey || e.ctrlKey || e.metaKey) return;
        e.preventDefault();
        ta.setRangeText('    ', ta.selectionStart, ta.selectionEnd, 'end');
        ta.dispatchEvent(new Event('input', { bubbles: true }));
    });

    // mousedown, not click: keep the textarea's selection from collapsing
    // before we read it.
    insert.addEventListener('mousedown', (e) => e.preventDefault());
    insert.addEventListener('click', () => {
        const s = ta.selectionStart ?? ta.value.length, t = ta.selectionEnd ?? s;
        ta.focus();
        ta.setRangeText(token, s, t, 'end');
        ta.dispatchEvent(new Event('input', { bubbles: true }));
        grow();
    });

    paint();
    return {
        key: field.key,
        node: row,
        wide: true,
        read() { return ta.value === '' ? { remove: true } : { value: ta.value }; },
    };
}

/* ─── helpers ────────────────────────────────────────────────────────── */

function escText(s) {
    return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}

// The AI models the server can actually reach. main.js loads them at start-up;
// fall back to asking if that hasn't landed (or failed).
async function fillModelOptions(select, current) {
    const render = (models) => {
        select.textContent = '';
        const none = document.createElement('option');
        none.value = '';
        none.textContent = 'No Model';
        select.appendChild(none);
        for (const m of models) {
            const opt = document.createElement('option');
            opt.value = m;
            opt.textContent = m;
            if (current === m) opt.selected = true;
            select.appendChild(opt);
        }
        // Keep a model the deck names but this server doesn't offer, so simply
        // opening the panel doesn't silently clear the presenter's choice.
        if (current && !models.includes(current)) {
            const opt = document.createElement('option');
            opt.value = current;
            opt.textContent = `${current} (unavailable)`;
            opt.selected = true;
            select.appendChild(opt);
        }
    };

    const known = ctx.state?.availableModels;
    if (Array.isArray(known) && known.length) { render(known); return; }

    const placeholder = document.createElement('option');
    placeholder.value = current == null ? '' : String(current);
    placeholder.textContent = current ? String(current) : '— loading… —';
    select.appendChild(placeholder);
    try {
        const data = await (await fetch(sessionUrl('/api/models'))).json();
        const models = data?.models || [];
        if (ctx.state) ctx.state.availableModels = models;
        render(models);
    } catch (_) {
        placeholder.textContent = 'Unavailable';
    }
}

// A file field's bytes go into the deck (and up to the server so the widget can
// read them before any save); the widget's config records only the path.
function pickWidgetAsset(field, item, input, btn) {
    const picker = document.createElement('input');
    picker.type = 'file';
    if (field.accept) picker.accept = field.accept;
    picker.addEventListener('change', async () => {
        const file = picker.files?.[0];
        if (!file) return;
        btn.disabled = true;
        btn.textContent = 'Opening…';
        try {
            const buffer = await file.arrayBuffer();
            const path = await saveWidgetAsset(item, {
                key: field.key, name: file.name, folder: field.folder || 'files', buffer,
            });
            if (path) {
                input.value = path; input.title = path;
                input.dispatchEvent(new Event('input', { bubbles: true }));
            }
        } catch (err) {
            // The file is still recorded and will be written into the deck on
            // save — it is only the live preview that can't be served. Say so,
            // rather than leaving a silent failure to resurface later as a
            // missing file inside the widget.
            console.warn('[editor] widget file upload failed:', err);
            window.BeamerModal?.show({
                kind: 'error',
                title: 'Upload Failed',
                message: `${err.message}\n\nThe file is still part of the presentation and will be included when you save, but the widget can't preview it until the upload succeeds.`,
            });
        } finally {
            btn.disabled = false;
            btn.textContent = 'Upload';
        }
    });
    picker.click();
}

/* ─── colour + count list: a swatch you click to pick a colour, and how many ─ */
// `type: "colour-counts"` — stored as [{ c: <option value>, n: <count> }, …].
// Options carry their own colour: { v, l, hex }. Each colour is used once; the
// swatch opens a small palette, and the count is a −/+ stepper.

function buildColourCountsRow(field, item) {
    const opts = (field.options || []).map(o => ({ v: o.v, l: o.l ?? String(o.v), hex: o.hex || '#888' }));
    const maxRows = Math.min(field.max || opts.length, opts.length);
    const nMin = field.countMin ?? 0, nMax = field.countMax ?? 99;
    const row = document.createElement('div');
    row.className = 'editor-prop-row wf-cc-row';
    row.appendChild(fieldLabel(field));
    const list = document.createElement('div');
    list.className = 'wf-cc';
    row.appendChild(list);
    const add = document.createElement('button');
    add.type = 'button';
    add.className = 'wf-list-add wf-cc-add';
    add.innerHTML = '<span aria-hidden="true">+</span> Add';
    add.setAttribute('aria-label', 'Add ' + (field.itemLabel || 'colour').toLowerCase());
    row.appendChild(add);

    const eff = fieldValue(item, field);
    let items = (Array.isArray(eff) ? eff : [])
        .map(x => ({ c: String(x?.c), n: Number(x?.n) }))
        .filter(x => opts.some(o => String(o.v) === x.c));
    const changed = () => list.dispatchEvent(new Event('input', { bubbles: true }));
    const optOf = c => opts.find(o => String(o.v) === String(c)) || opts[0];
    const clampN = n => Math.max(nMin, Math.min(nMax, Math.round(isNaN(n) ? nMin : n)));

    let pop = null;
    function closePop() {
        if (!pop) return;
        pop.remove(); pop = null;
        list.querySelectorAll('.wf-cc-swatch.is-open').forEach(b => b.classList.remove('is-open'));
        document.removeEventListener('pointerdown', outside, true);
        document.removeEventListener('keydown', onKey, true);
        window.removeEventListener('scroll', closePop, true);
        window.removeEventListener('resize', closePop);
    }
    function outside(e) { if (pop && !pop.contains(e.target) && !e.target.closest?.('.wf-cc-swatch.is-open')) closePop(); }
    function onKey(e) { if (e.key === 'Escape') { e.stopPropagation(); closePop(); } }
    function openPop(btn, idx) {
        const wasOpen = btn.classList.contains('is-open');
        closePop();
        list.querySelectorAll('.wf-cc-swatch.is-open').forEach(b => b.classList.remove('is-open'));
        if (wasOpen) return;
        btn.classList.add('is-open');
        pop = document.createElement('div');
        pop.className = 'wf-cc-pop';
        pop.setAttribute('role', 'listbox');
        const used = new Set(items.filter((_, j) => j !== idx).map(x => x.c));
        for (const o of opts) {
            const b = document.createElement('button');
            b.type = 'button';
            // The same swatch as the pen colours.
            b.className = 'custom-modal-pen-swatch wf-cc-choice';
            b.style.background = o.hex;
            b.title = o.l;
            b.setAttribute('aria-label', o.l);
            const cur = String(o.v) === items[idx].c;
            b.setAttribute('aria-selected', cur ? 'true' : 'false');
            b.classList.toggle('is-selected', cur);
            if (used.has(String(o.v))) { b.disabled = true; b.title = o.l + ' (already used)'; }
            b.addEventListener('click', () => {
                items[idx].c = String(o.v);
                closePop(); paint(); changed();
                list.querySelectorAll('.wf-cc-swatch')[idx]?.focus();
            });
            pop.appendChild(b);
        }
        document.body.appendChild(pop);
        const r = btn.getBoundingClientRect(), pr = pop.getBoundingClientRect();
        let top = r.bottom + 6;
        if (top + pr.height > window.innerHeight - 8) top = r.top - pr.height - 6;
        pop.style.left = Math.max(8, Math.min(window.innerWidth - pr.width - 8, r.left - 6)) + 'px';
        pop.style.top = top + 'px';
        (pop.querySelector('[aria-selected="true"]') || pop.querySelector('button:not(:disabled)'))?.focus();
        document.addEventListener('pointerdown', outside, true);
        document.addEventListener('keydown', onKey, true);
        window.addEventListener('scroll', closePop, true);
        window.addEventListener('resize', closePop);
    }

    function paint() {
        list.textContent = '';
        items.forEach((it, i) => {
            const o = optOf(it.c);
            const r = document.createElement('div');
            r.className = 'wf-cc-item';
            const sw = document.createElement('button');
            sw.type = 'button';
            sw.className = 'custom-modal-pen-swatch wf-cc-swatch';
            sw.style.background = o.hex;
            sw.title = o.l + ' — click to change';
            sw.setAttribute('aria-label', 'Colour: ' + o.l);
            sw.setAttribute('aria-haspopup', 'listbox');
            sw.addEventListener('click', () => openPop(sw, i));
            const name = document.createElement('span');
            name.className = 'wf-cc-name';
            name.textContent = o.l;
            const step = document.createElement('div');
            step.className = 'wf-cc-step';
            const minus = document.createElement('button');
            minus.type = 'button'; minus.textContent = '−'; minus.setAttribute('aria-label', 'Fewer');
            const num = document.createElement('input');
            num.type = 'text'; num.inputMode = 'numeric';
            num.className = 'wf-cc-num';
            num.value = String(it.n);
            num.setAttribute('aria-label', 'How many ' + o.l.toLowerCase());
            const plus = document.createElement('button');
            plus.type = 'button'; plus.textContent = '+'; plus.setAttribute('aria-label', 'More');
            const set = n => { it.n = clampN(n); num.value = String(it.n); minus.disabled = it.n <= nMin; plus.disabled = it.n >= nMax; changed(); };
            minus.disabled = it.n <= nMin; plus.disabled = it.n >= nMax;
            minus.addEventListener('click', () => set(it.n - 1));
            plus.addEventListener('click', () => set(it.n + 1));
            num.addEventListener('input', e => {
                e.stopPropagation();
                const v = parseInt(num.value, 10);
                if (!isNaN(v)) { it.n = clampN(v); changed(); }
            });
            num.addEventListener('change', e => { e.stopPropagation(); set(parseInt(num.value, 10)); });
            num.addEventListener('keydown', e => {
                if (e.key === 'ArrowUp') { e.preventDefault(); set(it.n + 1); }
                if (e.key === 'ArrowDown') { e.preventDefault(); set(it.n - 1); }
            });
            step.append(minus, num, plus);
            const rm = document.createElement('button');
            rm.type = 'button';
            rm.className = 'wf-list-remove';
            rm.title = 'Remove';
            rm.setAttribute('aria-label', 'Remove ' + o.l.toLowerCase());
            rm.innerHTML = '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" aria-hidden="true"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>';
            rm.disabled = items.length <= 1;
            rm.addEventListener('click', () => { closePop(); items.splice(i, 1); paint(); changed(); });
            r.append(sw, name, step, rm);
            list.appendChild(r);
        });
        add.hidden = items.length >= maxRows;
    }
    add.addEventListener('click', () => {
        const free = opts.find(o => !items.some(x => x.c === String(o.v)));
        if (!free) return;
        items.push({ c: String(free.v), n: clampN(field.addCount ?? 2) });
        paint(); changed();
        list.lastElementChild?.querySelector('.wf-cc-swatch')?.focus();
    });
    paint();

    return {
        key: field.key,
        node: row,
        wide: true,
        read() {
            if (!items.length) return { remove: true };
            const typed = v => (typeof opts[0]?.v === 'number' ? Number(v) : v);
            return { value: items.map(x => ({ c: typed(x.c), n: x.n })) };
        },
    };
}

/* ─── a list of choices: one dropdown per row, Add to add another ──── */
// `type: "select-list"` — stored as an array of option values, e.g. a set of
// dice [6, 6, 20]. Options are { v, l }; `max` caps the rows; `addValue` is
// what a new row starts as.

function buildSelectListRow(field, item) {
    const opts = (field.options || []).map(o => (o && typeof o === 'object' ? { v: o.v, l: o.l ?? String(o.v) } : { v: o, l: String(o) }));
    const maxRows = field.max || 99;
    const row = document.createElement('div');
    row.className = 'editor-prop-row wf-list-row';
    row.appendChild(fieldLabel(field));
    const list = document.createElement('div');
    list.className = 'wf-list';
    list.setAttribute('role', 'list');
    row.appendChild(list);
    const add = document.createElement('button');
    add.type = 'button';
    add.className = 'wf-list-add';
    add.innerHTML = '<span aria-hidden="true">+</span> Add';
    add.setAttribute('aria-label', 'Add ' + (field.itemLabel || 'item').toLowerCase());
    row.appendChild(add);

    const eff = fieldValue(item, field);
    let items = (Array.isArray(eff) ? eff : []).map(String).filter(v => opts.some(o => String(o.v) === v));
    const changed = () => list.dispatchEvent(new Event('input', { bubbles: true }));

    function paint() {
        list.textContent = '';
        items.forEach((val, i) => {
            const r = document.createElement('div');
            r.className = 'wf-list-item';
            r.setAttribute('role', 'listitem');
            const num = document.createElement('span');
            num.className = 'wf-list-num';
            num.textContent = String(i + 1);
            const sel = document.createElement('select');
            sel.className = 'field wf-list-input';
            sel.setAttribute('aria-label', `${field.itemLabel || 'Item'} ${i + 1}`);
            for (const o of opts) {
                const op = document.createElement('option');
                op.value = String(o.v);
                op.textContent = o.l;
                if (String(o.v) === val) op.selected = true;
                sel.appendChild(op);
            }
            sel.addEventListener('change', e => { e.stopPropagation(); items[i] = sel.value; changed(); });
            const rm = document.createElement('button');
            rm.type = 'button';
            rm.className = 'wf-list-remove';
            rm.title = 'Remove';
            rm.setAttribute('aria-label', 'Remove');
            rm.innerHTML = '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" aria-hidden="true"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>';
            rm.disabled = items.length <= 1;
            rm.addEventListener('click', () => { items.splice(i, 1); paint(); changed(); });
            r.append(num, sel, rm);
            list.appendChild(r);
        });
        add.hidden = items.length >= maxRows;
    }
    add.addEventListener('click', () => {
        items.push(String(field.addValue ?? items[items.length - 1] ?? opts[0]?.v));
        paint(); changed();
        list.lastElementChild?.querySelector('select')?.focus();
    });
    paint();

    return {
        key: field.key,
        node: row,
        wide: true,
        read() {
            if (!items.length) return { remove: true };
            const typed = v => (typeof opts[0]?.v === 'number' ? Number(v) : v);
            return { value: items.map(typed) };
        },
    };
}
