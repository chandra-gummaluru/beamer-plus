// Slide structure — labels and blank/view slide insertion & deletion.
// The structure is an array of { type: 'pdf'|'blank'|'view', ... } objects.
// A lot of state refers to slides by their position in that array
// (annotations, bookmarks, text boxes, view panes, the current and right-pane
// slide…), so every insert, delete and reorder goes through
// remapSlideIndices, which moves all of it in one place.
import { bus } from '../core/events.js';
import { discardParkedWidgets, requestWidgetStates, seedWidgetStates } from '../core/iframe-widget-renderer.js';

let _state = null;

export function initSlideStructure(state) {
    _state = state;
    // New page and duplicate: in the annotation toolbar while presenting,
    // in the insert toolbar while editing.
    for (const id of ['add-blank-btn', 'edit-add-page-btn'])
        // A plain blank page, straight in after the slide on stage. Its paper
        // (lined, grid…) is chosen in the editor's slide panel, like any blank's.
        document.getElementById(id)?.addEventListener('click', () => insertBlankAfterCurrent());
    for (const id of ['duplicate-slide-btn', 'edit-duplicate-btn'])
        document.getElementById(id)?.addEventListener('click', () => duplicateCurrentSlide());
    // In the editor the two slides are picked by clicking them (editor.js).
    document.getElementById('add-view-btn')?.addEventListener('click',  () => {
        if (_state.editMode) bus.emit('view:insert-pick'); else insertViewAfterCurrent();
    });
    bus.on('slide:delete', (i) => deleteSlideAt(i));
}

/* ─── labels ──────────────────────────────────────────────────── */
// "1", "2", … for PDF slides; "7a", "7b", … for blanks/views after slide 7.
export function getSlideLabels(structure) {
    const labels = [];
    let pdfCount = 0;
    let blankCount = 0;
    for (const obj of structure) {
        // A split widget slide's two halves are its own, never shown in the
        // navigator: no label of their own, and they don't use up a letter.
        if (obj.splitHalf) { labels.push(''); continue; }
        // A duplicated PDF page (it carries its own cfgId) is labelled like a
        // blank — "7a" — so copying a slide doesn't renumber the rest of the deck.
        if (obj.type !== 'blank' && obj.type !== 'view' && !obj.cfgId) {
            pdfCount++;
            blankCount = 0;
            labels.push(String(pdfCount));
        } else {
            blankCount++;
            const suffix = blankCount <= 26
                ? String.fromCharCode(96 + blankCount)
                : String(blankCount);
            labels.push(`${pdfCount}${suffix}`);
        }
    }
    return labels;
}

/* ─── real slides ─────────────────────────────────────────────── */
// Slides with content of their own — PDF pages and blanks, not view (split)
// slides, which only point at two others. Split view needs two of them.
export function realSlideCount(structure) {
    return (structure || []).filter(o => o && o.type !== 'view').length;
}

/* ─── config key ──────────────────────────────────────────────── */
// Which slideConfigs entry (and config/s<key>.json) holds a slide's media and
// widgets. PDF pages use their pdfIndex — except a duplicated page, which
// shows the same PDF page but owns its own config under `cfgId`. Blanks use
// their blankId. View slides have no config of their own.
export function configKeyOf(obj) {
    if (!obj) return null;
    if (obj.cfgId) return obj.cfgId;
    if (obj.type === 'pdf') return obj.pdfIndex;
    if (obj.type === 'blank') return obj.blankId ?? null;
    // A split view's config holds only its split widgets (slides/split-widgets.js):
    // the one widget that spans both of its slides.
    if (obj.type === 'view') return obj.viewId ?? null;
    return null;
}

/* ─── slide identity ──────────────────────────────────────────── */
// A key that stays with a slide wherever it moves in the deck. Positions
// change on every insert/delete/reorder; this doesn't. Widget iframes are
// tagged with it, so a slide's live widgets follow the slide instead of
// staying behind at its old position (and being handed to — or destroyed
// by — whichever slide lands there next).
//
// Held in a WeakMap on the structure object itself rather than derived from
// pdfIndex/blankId, so it works for every slide type and for older decks
// whose blanks carry no id. It lasts for the session; loading a deck builds
// new objects and so new keys (and discards every old widget anyway).
const _slideUids = new WeakMap();
let _nextSlideUid = 1;
export function slideUid(obj) {
    if (!obj || typeof obj !== 'object') return null;
    let uid = _slideUids.get(obj);
    if (!uid) { uid = 's' + (_nextSlideUid++); _slideUids.set(obj, uid); }
    return uid;
}

/* ─── index remapping ─────────────────────────────────────────── */
// The one place that moves position-keyed state after the structure array
// has changed. Call it *after* splicing the array, with `oldToNew(i)` giving
// slide i's new position, or null if slide i was removed.
//
//   · keyed data (annotations, bookmarks, text boxes) follows its slide, and
//     is dropped with it if the slide was removed
//   · view panes follow their slide; a pane whose slide was removed becomes
//     null — undefined, shown as "?" in the navigator and as an "Undefined"
//     card on stage — rather than silently pointing at some other slide
//   · pointers (current slide, right pane) follow their slide; one that
//     pointed at a removed slide falls back to whatever now sits in that
//     position, clamped to the deck
//   · the active view index follows its view, or clears if it was removed
//
// Editor-side state (the view slide being configured) listens for
// 'slides:remapped' and follows the same mapping.
export function remapSlideIndices(oldToNew) {
    const s = _state;
    const n = s.slideStructure.length;
    const moveKeys = (map) => {
        const out = {};
        for (const [key, val] of Object.entries(map || {})) {
            const j = oldToNew(parseInt(key, 10));
            if (j != null) out[j] = val;
        }
        return out;
    };
    const movePtr = (i) => {
        if (i == null) return i;
        const j = oldToNew(i);
        return j != null ? j : Math.max(0, Math.min(i, n - 1));
    };

    s.annotations = moveKeys(s.annotations);
    s.bookmarks   = moveKeys(s.bookmarks);
    if (s.textBoxes) s.textBoxes = moveKeys(s.textBoxes);

    const movePane = (i) => (i == null ? i : oldToNew(i));   // null: its slide is gone
    for (const obj of s.slideStructure) {
        if (obj.type !== 'view') continue;
        if (obj.left  !== undefined) obj.left  = movePane(obj.left);
        if (obj.right !== undefined) obj.right = movePane(obj.right);
    }
    s.currentSlide    = movePtr(s.currentSlide);
    s.rightSlideIndex = movePtr(s.rightSlideIndex);
    if (s.currentViewIndex != null) s.currentViewIndex = oldToNew(s.currentViewIndex);
    s.totalSlides = n;

    bus.emit('slides:remapped', oldToNew);
}

const shiftedFrom = (atIdx) => (i) => (i >= atIdx ? i + 1 : i);
const removedAt   = (atIdx) => (i) => (i === atIdx ? null : i > atIdx ? i - 1 : i);

// Delete the slide at `idx`, taking its position-keyed data and its live
// widgets with it. Used for blanks here and for view slides by the editor.
export function removeSlideAt(idx) {
    const [gone] = _state.slideStructure.splice(idx, 1);
    if (!gone) return;
    // Its widgets were parked under the slide's own key and nothing will
    // ever show that slide again — shut them down rather than leaving
    // hidden iframes (and their sockets and timers) running.
    const uid = slideUid(gone);
    discardParkedWidgets('L:' + uid);
    discardParkedWidgets('R:' + uid);
    remapSlideIndices(removedAt(idx));
}

/* ─── blank / view slide management ───────────────────────────── */

/* ─── add page ────────────────────────────────────────────────── */
// The add button inserts a plain blank page; its paper is changed in edit
// mode (the slide panel's paper picker).
function insertBlankAfterCurrent(paper = null) {
    // On an empty deck (fresh session, nothing uploaded) there is no "current"
    // slide to insert after — the blank becomes slide 0. Otherwise it lands
    // immediately after the slide on stage.
    const ins = _state.slideStructure.length === 0 ? 0 : _state.currentSlide + 1;
    const blankId = `b${Date.now()}`;
    const obj = { type: 'blank', blankId, parent: null };
    if (paper) obj.paper = paper;
    _state.slideStructure.splice(ins, 0, obj);
    remapSlideIndices(shiftedFrom(ins));
    // Refresh first so totalSlides / the navigator know about the new slide
    // before anything navigates to it.
    bus.emit('nav:refresh');
    bus.emit('slide:goto', ins);
}

// The two slides a new split view pairs: the last two before it — the slide
// on stage on the right, the one before it on the left (on slide 8: 7 | 8).
// View slides are skipped. On the first slide there is nothing before it, so
// it pairs with the one after instead.
function defaultViewPanes(structure, current) {
    const real = (i) => structure[i] && structure[i].type !== 'view';
    const prevReal = (i) => { for (let j = i - 1; j >= 0; j--) if (real(j)) return j; return null; };
    const nextReal = (i) => { for (let j = i + 1; j < structure.length; j++) if (real(j)) return j; return null; };
    let right = real(current) ? current : prevReal(current);
    if (right == null) right = nextReal(current);
    if (right == null) return null;
    const left = prevReal(right);
    if (left != null) return { left, right };
    const after = nextReal(right);
    return after != null ? { left: right, right: after } : null;
}

/**
 * Put a split view right after the current slide. `chosen` ({ left, right },
 * positions as they are now) picks its two slides; without it, sensible
 * neighbours are used.
 */
export function insertViewAfterCurrent(chosen = null) {
    if (realSlideCount(_state.slideStructure) < 2) return;   // nothing to pair
    const panes = chosen || defaultViewPanes(_state.slideStructure, _state.currentSlide);
    if (!panes) return;
    const ins    = _state.currentSlide + 1;
    const viewId = `v${Date.now()}`;

    // The panes are worked out before the splice; the view goes in right
    // after the current slide, so anything at or past `ins` moves up one.
    // The new view has no panes yet, so the remap leaves it alone.
    _state.slideStructure.splice(ins, 0, { type: 'view', viewId, ratio: 50 });
    remapSlideIndices(shiftedFrom(ins));
    const shift = shiftedFrom(ins);

    _state.slideStructure[ins].left  = shift(panes.left);
    _state.slideStructure[ins].right = shift(panes.right);

    bus.emit('nav:refresh');
    if (_state.editMode) bus.emit('view:select', ins);
    // And open it, so the new pair is on stage straight away.
    bus.emit('slide:goto', ins);
}

/**
 * A split widget slide: one widget across a split, as a slide of its own.
 * It is a view slide (widgetLabel set) over two blank halves that belong to
 * it (splitHalf: hidden, unlabelled, not in the navigator), with the widget
 * in the view's config. Goes in after the current slide and is opened.
 */
export function insertSplitWidgetSlide({ type, split, label }) {
    const s = _state;
    const ins = s.slideStructure.length ? s.currentSlide + 1 : 0;
    const t = Date.now();
    const viewId = `v${t}`;
    const half = (k) => ({ type: 'blank', blankId: `b${t}${k}`, parent: null, hidden: true, splitHalf: true });
    s.slideStructure.splice(ins, 0, { type: 'view', viewId, ratio: 50, widgetLabel: label }, half('l'), half('r'));
    remapSlideIndices((i) => (i >= ins ? i + 3 : i));
    // The remap moved anything at or past `ins` — the new three included —
    // so set the view's panes after it.
    s.slideStructure[ins].left = ins + 1;
    s.slideStructure[ins].right = ins + 2;
    s.slideConfigs[viewId] = { widgets: [{
        id: `widget_${t}`, type, src: '', builtin: true,
        x: 0, y: 0, width: 1, height: 1, zIndex: 10,
        split: { left: split?.left?.[0] || 'editor', right: split?.right?.[0] || 'shell' },
    }] };
    bus.emit('nav:refresh');
    if (s.editMode) bus.emit('view:select', ins);
    bus.emit('slide:goto', ins);
}

/** Delete a split widget slide: the view and the two halves it owns. */
export function removeSplitWidgetSlide(viewIdx) {
    const s = _state;
    const v = s.slideStructure[viewIdx];
    if (!v || v.type !== 'view') return;
    const owned = [v.left, v.right].filter(i => Number.isInteger(i) && s.slideStructure[i]?.splitHalf);
    if (s.slideConfigs[v.viewId]) delete s.slideConfigs[v.viewId];
    // Highest first, so the lower indices stay put while removing.
    for (const i of [viewIdx, ...owned].sort((a, b) => b - a)) removeSlideAt(i);
    bus.emit('split-widgets:changed');
}

// Delete any slide (Remove slide in the editor panel, edit mode). A PDF
// page removed this way leaves the deck; its page stays in slides.pdf, so
// re-uploading the deck brings it back.
function deleteSlideAt(idx) {
    const s = _state;
    if (!s.editMode || idx < 0 || idx >= s.slideStructure.length) return;
    const wasCurrent = idx === s.currentSlide;
    removeSlideAt(idx);
    const n = s.slideStructure.length;
    s.currentSlide = Math.max(0, Math.min(wasCurrent ? idx : s.currentSlide, n - 1));
    bus.emit('nav:refresh');
    if (n) bus.emit('slide:goto', s.currentSlide);
}

/* ─── duplicate ───────────────────────────────────────────────── */
// Insert a copy of the slide on stage right after it, and go to the copy.
// The copy is fully independent: its own config (media and widgets, the
// widgets with fresh ids so they run as separate instances, seeded with the
// originals' current state), its own annotations and text boxes.
//   · PDF page → a PDF entry for the same page with its own cfgId
//   · blank    → a new blank with a new blankId
//   · view     → a new view slide pointing at the same two panes
let _duplicating = false;
async function duplicateCurrentSlide() {
    const s = _state;
    if (_duplicating || !s.slideStructure.length) return;
    const src = s.slideStructure[s.currentSlide];
    if (!src) return;
    _duplicating = true;
    try {
        // Commit the strokes on stage so the copy gets them.
        bus.emit('annotations:flush');

        const stamp = Date.now();
        let copy;
        if (src.type === 'view') {
            copy = { ...src, viewId: `v${stamp}` };
        } else if (src.type === 'blank') {
            copy = { type: 'blank', blankId: `b${stamp}`, parent: src.parent ?? null };
            if (src.paper) copy.paper = { ...src.paper };
        } else {
            copy = { type: 'pdf', pdfIndex: src.pdfIndex, cfgId: `d${stamp}` };
        }
        if (src.hidden) copy.hidden = true;   // same visibility as the original
        if (src.title) copy.title = src.title;

        // Clone the config (media + widgets) under the copy's key.
        const srcKey = configKeyOf(src);
        const newKey = configKeyOf(copy);
        if (newKey != null && srcKey != null) {
            const srcCfg = await _readConfig(srcKey);
            if (srcCfg) {
                const cfg = JSON.parse(JSON.stringify(srcCfg));
                if (Array.isArray(cfg.widgets) && cfg.widgets.length) {
                    const oldIds = cfg.widgets.map(w => String(w.id));
                    const states = await requestWidgetStates(oldIds);
                    const seeded = {};
                    cfg.widgets.forEach((w, i) => {
                        const oldId = String(w.id);
                        w.id = `widget_${stamp}_${i}`;
                        if (states[oldId] !== undefined) seeded[w.id] = states[oldId];
                    });
                    seedWidgetStates(seeded);
                }
                s.slideConfigs[newKey] = cfg;
            } else {
                s.slideConfigs[newKey] = null;
            }
        }

        const from = s.currentSlide;
        const ins = from + 1;
        s.slideStructure.splice(ins, 0, copy);
        remapSlideIndices(shiftedFrom(ins));
        // After the remap the source is still at `from`; copy its keyed data.
        if (s.annotations?.[from]) s.annotations[ins] = s.annotations[from];
        if (s.textBoxes?.[from]) s.textBoxes[ins] = JSON.parse(JSON.stringify(s.textBoxes[from]));

        bus.emit('nav:refresh');
        bus.emit('slide:goto', ins);
    } finally {
        _duplicating = false;
    }
}

// A slide's config as it stands: the in-memory copy if it has been loaded
// (possibly edited) this session, else the file in the deck.
async function _readConfig(key) {
    const cfgs = _state.slideConfigs || {};
    if (Object.prototype.hasOwnProperty.call(cfgs, key) && cfgs[key] !== undefined) return cfgs[key];
    try {
        const f = _state.zipFile?.file(`config/s${key}.json`);
        return f ? JSON.parse(await f.async('string')) : null;
    } catch { return null; }
}
